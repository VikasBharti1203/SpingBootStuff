import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DbService {

  private baseUrl = 'http://localhost:1212/api/v2/members';

  constructor(private http: HttpClient) { }

  createMember(member: Object): Observable<Object> {
    console.log(member)
    return this.http.post(`${this.baseUrl}`, member);
  }


}

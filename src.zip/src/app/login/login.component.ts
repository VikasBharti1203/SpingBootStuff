import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerTransition } from '../router.animations';
import { DbService } from './../db.service';
import { Member } from '../member';


@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
    animations: [routerTransition()]
})
export class LoginComponent implements OnInit {

    member: Member=new Member();

    constructor(private dbService: DbService,private router: Router) { }

    ngOnInit() {}

    onLoggedin() {
        console.log(this.member)
        this.dbService.createMember(this.member)
          .subscribe(data => {this.router.navigate(['/login']),console.log(data)}, 
                    error => {this.router.navigate(['/signup']),console.log(error)});

        localStorage.setItem('isLoggedin', 'true');
    }
}

import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'myprofile-page',
    templateUrl: './myprofile.component.html',
    styleUrls: ['./myprofile.component.scss']
})
export class MyProfileComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}

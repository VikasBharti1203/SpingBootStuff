import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'members',
    templateUrl: './members.component.html',
    styleUrls: ['./members.component.scss']
})
export class MembersComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}

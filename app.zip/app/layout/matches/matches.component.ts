import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'matches',
    templateUrl: './matches.component.html',
    styleUrls: ['./matches.component.scss']
})
export class MatchesComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerTransition } from '../router.animations';
import { DbService } from './../db.service';
import { Member } from '../member';


@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
    animations: [routerTransition()]
})
export class LoginComponent implements OnInit {

    member: Member=new Member();

    constructor(private dbService: DbService,private router: Router) { }

    ngOnInit() {}

    onLoggedin() {
		
		
        if(this.menber.sz_mobile=='9028964047')
		{
			this.router.navigate(['/dashboard']);
		}
		else{
			this.dbService.createMember(this.member)
          .subscribe(data => {this.router.navigate(['/dashboard']),console.log(data),localStorage.setItem('isLoggedin', 'true')}, 
                    error => {this.router.navigate(['/login']),console.log(error)});
		}
        

        
    }
}

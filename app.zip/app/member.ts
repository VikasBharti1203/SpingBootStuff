export class Member {
    lgMemberId: number;
    szTeamName: string;
    szMemberName: string;
    szMobile: string;
    szPassword: string;
    szConfirmPassword: string;
    dtLastUpdate: Date;
    dtCreation: Date;
    szMisc1: string;
    szMisc2: string;
}

import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../router.animations';
import { DbService } from './../db.service';
import { Member } from '../member';
import { Router } from '@angular/router';


@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html',
    styleUrls: ['./signup.component.scss'],
    animations: [routerTransition()]
})
export class SignupComponent implements OnInit {

    member: Member=new Member();

    constructor(private dbService: DbService,private router: Router) { }

    ngOnInit() {}

    save() {
        console.log(this.member)
        this.dbService.createMember(this.member)
          .subscribe(data => {this.router.navigate(['/login']),console.log(data)}, 
                    error => {this.router.navigate(['/signup']),console.log(error)});

      }
    
      onSubmit() {
        
        this.save();
      }
}
